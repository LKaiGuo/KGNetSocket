﻿/****************************************************
    文件：TextExtension.cs
	作者：KG
    邮箱: 695907593@qq.com
    日期：#CreateTime#
	功能：Nothing
*****************************************************/
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public static class ImageExtension  
{
    public static void LoadImage(this RawImage rawImage,byte[] data,int Width=200,int Height=200)
    {
        Texture2D texture2D = new Texture2D(Width, Height);
        texture2D.LoadImage(data);
        rawImage.texture = texture2D;

    }

    public static Texture2D ByteToTexture(this byte[] data, int Width = 200, int Height = 200)
    {
        Texture2D texture2D = new Texture2D(Width, Height);
        texture2D.LoadImage(data);
        return texture2D;

    }

    /// <summary>
    /// 路劲图片文件转byte[]
    /// </summary>
    /// <param name="filename填写图片路径"></param>
    /// <returns></returns>
    public static byte[] GetPictureBytes(this string filename)
    {
        FileInfo fileInfo = new FileInfo(filename);
        byte[] buffer = new byte[fileInfo.Length];
        using (FileStream stream = fileInfo.OpenRead())
        {
            stream.Read(buffer, 0, buffer.Length);
        }
        return buffer;
    }

}