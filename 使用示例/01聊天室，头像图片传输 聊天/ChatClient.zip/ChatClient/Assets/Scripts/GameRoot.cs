﻿/****************************************************
    文件：GameRoot.cs
	作者：KG
    邮箱: 695907593@qq.com
    日期：#CreateTime#
	功能：Nothing
*****************************************************/
using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms;
using UnityEngine;
using KGSocket;
using ChatNetData;
using UnityEngine.UI;
using System.IO;
using System;
using KGSocket.Tool;


public class GameRoot : MonoBehaviour
{

    public KGSocketClient<ChatNetSession, ChatDatas> socketClient = new KGSocketClient<ChatNetSession, ChatDatas>();

    public KGHeartBeatManage<ChatNetSession, KGHeartBeat> heartBeatManage;

    public Queue<ChatDatas> ChatQue = new Queue<ChatDatas>();
    private static readonly string obj = "lock";



    public LoginPanel loginPanel;
    public ChatPanel chatPanel;

    public Text ErrorTxt;



    public byte[] HeadData;




    private void Awake()
    {
        loginPanel.gameObject.SetActive(true);
        chatPanel.gameObject.SetActive(false);
    }
    void Start()
    {
        socketClient.StartCreate("192.168.2.28", 8895);
       
        socketClient.Client.OnStartReciveEvent += () => 
        {
           
            heartBeatManage = new KGHeartBeatManage<ChatNetSession, KGHeartBeat>(send =>
            {
                socketClient.Client.SendData(new ChatDatas {Cmd=(int)CMD.HeartBeat });
            }, obj =>
            {
                Debug.Log("心跳包超时准备断开连接");
                if (obj!=null)
                {
                    Debug.Log(heartBeatManage.ConnectDic[obj].Lostcount);
                    obj.Clear();
                }
               
            });
            heartBeatManage.AddConnectDic(socketClient.Client,null,5,5);
        };


        InItClickEvent();
    }

    // Update is called once per frame
    void Update()
    {
     
        if (ChatQue.Count > 0)
        {
            Debug.Log(ChatQue.Count);
            lock (obj)
            {

                //出列 处理
                ProcessNetData(ChatQue.Dequeue());
            }
        }
    }


    /// <summary>
    /// 接收事件存入队列
    /// </summary>
    /// <param name="info"></param>
    public void AddNetData(ChatDatas info)
    {
        lock (obj)
        {
            ChatQue.Enqueue(info);
        }
    }

    /// <summary>
    /// 处理接收的数据
    /// </summary>
    /// <param name="info"></param>
    public void ProcessNetData(ChatDatas info)
    {
        Debug.Log((CMD)(info.Cmd));
        //先判断是否有错误
        if ((ErrorInfo)(info.Err) != ErrorInfo.None)
        {
          
            switch ((ErrorInfo)(info.Err))
            {
                case ErrorInfo.NameRepeatsErr:
                    StartDelayTxt("用户名重复请更换");
                    loginPanel.LoginBtn.interactable = true;
                    break;

            }
            return;
        }

        //然后判断收到的指令 做处理
        switch ((CMD)(info.Cmd))
        {
            case CMD.HeartBeat:
                //接收到心跳包 刷新
              if(heartBeatManage!=null)
                heartBeatManage.UpdateOneHeat(socketClient.Client);
              
                break;
            case CMD.RspLogin:
                loginPanel.gameObject.SetActive(false);
                chatPanel.gameObject.SetActive(true);
                chatPanel.HeadImg.LoadImage(info.HeadData);
                chatPanel.PlayerNameTxt.text = info.PlayerName;
                // StartCoroutine(DownloadImage(dialog.FileName, v => loginPanel.PlayerHead.texture = v));
                break;
            case CMD.RspChatInfo:
                Debug.Log(info.PlayerName);
                chatPanel.SpawnDialogUI(info.PlayerName, info.Chatdata.chat, info.HeadData.ByteToTexture(), info.Chatdata.Islocal);
                
                break;

        }
    }

    /// <summary>
    /// 按钮绑定事件
    /// </summary>
    public void InItClickEvent()
    {

        //接收事件
        socketClient.Client.OnReciveDataEvent += AddNetData;
        //登录按钮
        loginPanel.LoginBtn.onClick.AddListener(() =>
        {
            if (loginPanel.PlayerHead.texture.name== "unselected"|| loginPanel.NameInput.text=="")
            {
                StartDelayTxt("未选择头像或者名字为空 不能登录");
            }
            else
            {

                loginPanel.LoginBtn.interactable = false;
                socketClient.Client.SendData(new ChatDatas
                {
                    Cmd = (int)(CMD.ReqLogin),
                    PlayerName = loginPanel.NameInput.text,
                    HeadData = this.HeadData

                });




            }
        });

        loginPanel.SelectHeadBtn.onClick.AddListener(() =>
        {
            OpenFile();
        });

        //      发送消息按钮
        chatPanel.SendChatBtn.onClick.AddListener(() =>
        {
            if (chatPanel.chatInput.text == "")
            {
                StartDelayTxt("发送的内容不能为空");
            }
            else
            {
                ChatDatas chat = new ChatDatas
                {
                    Cmd = (int)(CMD.ReqChatInfo),

                    Chatdata = new SendChat() { chat = chatPanel.chatInput.text },
                };

                socketClient.Client.SendData(chat);
                chatPanel.chatInput.text = "";
            }
        });


        socketClient.SetLog((v, l) =>
        {
            Debug.Log(v + "Level:" + l);
        });

    }


    private void OnDestroy()
    {
        heartBeatManage.Dispose();
        socketClient.Client.Clear();
    }
    #region 工具


    /// <summary>
    /// 这个是打开选择文件的
    /// </summary>
    public void OpenFile()
    {
        OpenFileDialog dialog = new OpenFileDialog();
        dialog.Filter = "PNG图片|*.png|JPG图片|*.jpg";  //过滤文件类型
        
        dialog.InitialDirectory = UnityEngine.Application.dataPath;  //定义打开的默认文件夹位置，可以在显示对话框之前设置好各种属性
        if (dialog.ShowDialog() == DialogResult.OK)
        {
            HeadData = dialog.FileName.GetPictureBytes();
            StartCoroutine(DownloadImage(dialog.FileName, v => loginPanel.PlayerHead.texture = v));

        }
       
    }

    //加载路径图片
    IEnumerator DownloadImage(string url, Action<Texture2D> action)
    {
        WWW www = new WWW(url);
        yield return www;
        action(www.texture);


    }


    /// <summary>
    /// 提示错误信息文字
    /// </summary>
    public void StartDelayTxt(string info)
    {
        ErrorTxt.text = info;
        StopAllCoroutines();
        StartCoroutine(DelayTxt());
    }

    IEnumerator DelayTxt()
    {
        ErrorTxt.gameObject.SetActive(true);
        yield return new WaitForSeconds(2);
        ErrorTxt.gameObject.SetActive(false);
    }
    #endregion

}