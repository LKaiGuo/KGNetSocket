﻿/****************************************************
    文件：NetSession.cs
	作者：KG
    邮箱: 695907593@qq.com
    日期：#CreateTime#
	功能：Nothing
*****************************************************/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using KGSocket;
using ChatNetData;

public class ChatNetSession : KGNetSession<ChatDatas> 
{

}