﻿/****************************************************
    文件：LoginPanel.cs
	作者：KG
    邮箱: 695907593@qq.com
    日期：#CreateTime#
	功能：Nothing
*****************************************************/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class LoginPanel : MonoBehaviour 
{

    public InputField NameInput;

    public RawImage PlayerHead;

    public Button LoginBtn;

    public Button SelectHeadBtn;

   
  



}