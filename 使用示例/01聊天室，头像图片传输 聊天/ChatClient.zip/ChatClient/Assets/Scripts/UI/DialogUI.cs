﻿/****************************************************
    文件：DialogUI.cs
	作者：KG
    邮箱: 695907593@qq.com
    日期：#CreateTime#
	功能：Nothing
*****************************************************/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogUI : MonoBehaviour 
{
    public RectTransform Dialogui;
    public RectTransform DialogBox;
    public RectTransform HeadBG;

    public RawImage HeadImg;

    public Text DialogTxt;
    public Text PlayerNameTxt;

    private void Start()
    {
      //  InitDialog("啊啊啊啊啊啊啊啊啊\n啊啊啊啊啊啊啊啊");
    }



    /// <summary>
    /// 设置我方的对话位置 内容
    /// </summary>
    /// <param name="info"></param>
    /// <returns></returns>
    public DialogUI InitLocalDialog(string playername,string info, Texture2D head)
    {
        //这边是左边的边界离父物体的左边距离635
        HeadBG.offsetMax = new Vector2(627, HeadBG.offsetMax.y);
        HeadBG.offsetMin = new Vector2(0, HeadBG.offsetMin.y);

        InitDialog(playername,info, head);
        
        DialogBox.anchoredPosition = new Vector2(-DialogBox.anchoredPosition.x, DialogBox.anchoredPosition.y);

        //设置旋转
        DialogBox.transform.localEulerAngles = new Vector3(0, 180, 0);
        DialogTxt.transform.localEulerAngles = new Vector3(0, 180, 0);
        return this;
    }

    /// <summary>
    /// 设置对方的对话位置 内容
    /// </summary>
    /// <param name="info"></param>
    /// <returns></returns>
    public DialogUI InitDialog(string playername, string info,Texture2D head)
    {
        PlayerNameTxt.text = playername;
        
        DialogTxt.text = info;


        //DialogBox聊天框
        //DialogTxt文本
        //preferredWidth是获取该文本的文字 最宽的一段的长度   如果超过540长度 就宽度上限了
        if ((int)(DialogTxt.preferredWidth / 540) == 0)
        {

            //没超过设置的540之前，他的宽度是 TXT和聊天框两边的差距+文字的长度   
            DialogBox.sizeDelta = new Vector2(Mathf.Abs(DialogTxt.rectTransform.sizeDelta.x) + DialogTxt.preferredWidth, DialogBox.sizeDelta.y);
            
        }
        else
        {
            //超过最大宽度540了 就一直设置540就好
            DialogBox.sizeDelta = new Vector2(540, DialogBox.sizeDelta.y);
        }
        //就是原本 是原本100高度+文本高度
        Dialogui.sizeDelta = new Vector2(Dialogui.sizeDelta.x, 100 + DialogTxt.preferredHeight);

        HeadImg.texture = head;
        return this;
    }

    

}