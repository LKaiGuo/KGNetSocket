﻿/****************************************************
    文件：ChatPanel.cs
	作者：KG
    邮箱: 695907593@qq.com
    日期：#CreateTime#
	功能：Nothing
*****************************************************/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChatPanel : MonoBehaviour 
{
    public Button SendChatBtn;

    public RawImage HeadImg;

    public Text PlayerNameTxt;

    public RectTransform DialogParent;

    public DialogUI DialogUIPrefab;

    public InputField chatInput;


    /// <summary>
    /// 生成对话框  懒得写枚举了。用int吧  0我方 其他对方
    /// </summary>
    /// <param name="i"></param>
    /// <returns></returns>
    public DialogUI SpawnDialogUI(string playername, string info,Texture2D  head, int i=0)
    {

        DialogUI dialogUI;
        if (i==0)
        {
             dialogUI = Instantiate(DialogUIPrefab, DialogParent.transform).InitLocalDialog(playername, info, head);
        }
        else
        {
            dialogUI = Instantiate(DialogUIPrefab, DialogParent.transform).InitDialog(playername, info, head);
        }
        //下拉对话框 上面应该会延时 所以这里也需要延时
       Invoke("HaulDown",0.02f);
    
        return dialogUI;


    }

    public void HaulDown()
    {
        DialogParent.anchoredPosition = new Vector2(DialogParent.anchoredPosition.x, DialogParent.sizeDelta.y);
    }
}