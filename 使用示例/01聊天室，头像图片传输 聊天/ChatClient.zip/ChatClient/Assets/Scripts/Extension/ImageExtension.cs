﻿/****************************************************
    文件：TextExtension.cs
	作者：KG
    邮箱: 695907593@qq.com
    日期：#CreateTime#
	功能：Nothing
*****************************************************/
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public static class ImageExtension  
{
    public static void LoadImage(this RawImage rawImage,byte[] data,int Width=200,int Height=200)
    {
        Texture2D texture2D = new Texture2D(Width, Height);
        texture2D.LoadImage(data);
        rawImage.texture = texture2D;

    }

    public static Texture2D ByteToTexture(this byte[] data, int Width = 200, int Height = 200)
    {
        Texture2D texture2D = new Texture2D(Width, Height);
        texture2D.LoadImage(data);
        return texture2D;

    }

}